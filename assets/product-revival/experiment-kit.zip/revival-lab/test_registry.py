import copy
import csv
import json
import tempfile
import unittest
from pathlib import Path

import registry


ROOT = Path(__file__).resolve().parent


class RegistryTests(unittest.TestCase):
    def setUp(self):
        self.data = registry.load(ROOT / "registry.planned.json")
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name)

    def observation(self, scope="simulation", observation_id="test-observation"):
        source_type = {"actual": "measurement_export", "claimed": "source_case", "simulation": "simulation_fixture"}[scope]
        source_id = "test-source-" + scope
        self.data["sources"].append({"source_id": source_id, "title": "Test fixture provenance", "url": "https://example.com/case" if scope == "claimed" else None, "evidence_type": source_type, "recorded_on": "2026-10-02", "country": "GB", "reference": source_id})
        row = {"observation_id": observation_id, "experiment_id": "pilates-hook-001", "creative_id": "pilates-hook-001-a", "scope": scope, "stage": "organic", "country": "GB", "start_on": "2026-10-01", "end_on": "2026-10-01", "source_id": source_id, "counts": {"video_impressions": 1000, "content_plays": 400, "destination_clicks": 20, "landing_sessions": 10, "checkout_starts": 3, "orders": 2, "new_customers": 1}, "notes": "Synthetic test fixture only"}
        self.data["observations"].append(row)
        return row

    def cost(self, row, amount="12.00", category="variable_acquisition"):
        cost = {"cost_id": "test-cost", "experiment_id": row["experiment_id"], "creative_id": row["creative_id"], "observation_id": row["observation_id"], "scope": row["scope"], "category": category, "amount_gbp": amount, "source_id": row["source_id"], "ledger_ref": None}
        if row["scope"] == "actual":
            cost.update(amount_gbp=None, source_id=None, ledger_ref={"store": "shared", "cost_id": "traffic-001"})
        self.data["costs"].append(cost)
        return cost

    def report(self):
        return registry.make_report(self.data, "2026-10-02")

    def test_initial_registry_is_planned_with_no_actual_or_simulated_records(self):
        report = self.report()
        self.assertEqual(report["actual_observation_records"], 0)
        self.assertEqual(report["observations"], [])
        self.assertEqual(len(self.data["creatives"]), 6)
        self.assertTrue(all(c["stage"] == "planned" for c in self.data["creatives"]))

    def test_shortlist_has_two_candidates_and_only_hook_changes(self):
        shortlist = registry.validate(registry.load(ROOT / "registry.shortlist.json"))
        self.assertEqual({p["product_id"] for p in shortlist["products"]}, {"heatless-curl-comfort-kit", "adjustable-blackout-sleep-mask"})
        self.assertEqual(shortlist["observations"], [])
        self.assertEqual(shortlist["costs"], [])
        self.assertEqual(len(shortlist["creatives"]), 6)
        for experiment in shortlist["experiments"]:
            self.assertEqual(experiment["changed_factors"], ["hook"])
            variants = [c for c in shortlist["creatives"] if c["experiment_id"] == experiment["experiment_id"]]
            self.assertEqual(len(variants), 3)
            self.assertEqual(len({c["factors"]["hook"] for c in variants}), 3)
            for factor in registry.FACTORS:
                if factor != "hook":
                    self.assertEqual(len({c["factors"][factor] for c in variants}), 1)
            self.assertTrue(all(c["stage"] == "planned" and c["footage_rights"]["status"] == "unknown" for c in variants))

    def test_actual_simulation_and_claimed_are_separate(self):
        self.observation("actual", "own-record")
        self.observation("simulation", "simulation-record")
        self.observation("claimed", "case-record")
        report = self.report()
        self.assertEqual(report["scope_record_counts"], {"actual": 1, "claimed": 1, "simulation": 1})
        self.assertEqual(report["actual_observation_records"], 1)
        self.assertNotIn("revenue", report)

    def test_case_source_cannot_become_actual(self):
        row = self.observation("claimed")
        row["scope"] = "actual"
        with self.assertRaisesRegex(registry.RegistryError, "measurement_export"):
            self.report()

    def test_identical_import_deduplicates_conflict_is_atomic(self):
        row = self.observation()
        destination = self.path / "incoming.json"
        registry.save(destination, [row])
        clean, added = registry.import_observations(self.data, destination)
        self.assertEqual(added, 0)
        self.assertEqual(len(clean["observations"]), 1)
        incoming = copy.deepcopy(row)
        incoming["counts"]["orders"] = 3
        registry.save(destination, [incoming])
        before = copy.deepcopy(self.data)
        with self.assertRaisesRegex(registry.RegistryError, "Conflicting duplicate"):
            registry.import_observations(self.data, destination)
        self.assertEqual(self.data, before)

    def test_overlap_rejects_duplicate_snapshot_under_another_id(self):
        row = self.observation()
        other = copy.deepcopy(row)
        other["observation_id"] = "different-id"
        self.data["observations"].append(other)
        with self.assertRaisesRegex(registry.RegistryError, "Overlapping"):
            self.report()

    def test_missing_denominator_remains_unknown(self):
        row = self.observation()
        row["counts"]["landing_sessions"] = None
        result = self.report()["observations"][0]
        self.assertIsNone(result["rates"]["orders_per_landing_session"]["value"])
        self.assertIsNone(result["variable_acquisition_gbp"])
        self.assertIsNone(result["rates"]["cac_per_new_customer_gbp"]["value"])

    def test_future_observations_cannot_enter_an_earlier_report(self):
        self.observation()
        with self.assertRaisesRegex(registry.RegistryError, "report date"):
            registry.make_report(self.data, "2026-09-30")

    def test_zero_orders_is_not_zero_cac_or_cpa(self):
        row = self.observation()
        self.cost(row)
        row["counts"].update(orders=0, new_customers=0)
        result = self.report()["observations"][0]
        self.assertIsNone(result["rates"]["cost_per_order_gbp"]["value"])
        self.assertIsNone(result["rates"]["cac_per_new_customer_gbp"]["value"])
        self.assertEqual(result["rates"]["orders_per_landing_session"]["value"], "0.0000")

    def test_rate_units_and_cost_denominators(self):
        row = self.observation()
        self.cost(row)
        rates = self.report()["observations"][0]["rates"]
        self.assertEqual(rates["destination_clicks_per_video_impression"]["value"], "0.0200")
        self.assertEqual(rates["destination_clicks_per_content_play"]["value"], "0.0500")
        self.assertEqual(rates["orders_per_landing_session"]["value"], "0.2000")
        self.assertEqual(rates["cost_per_order_gbp"]["value"], "6.00")
        self.assertEqual(rates["cac_per_new_customer_gbp"]["value"], "12.00")

    def test_sample_and_setup_do_not_enter_acquisition_cost(self):
        row = self.observation()
        self.cost(row, "100.00", "sample")
        other = copy.deepcopy(self.data["costs"][0])
        other.update(cost_id="setup-cost", category="setup")
        self.data["costs"].append(other)
        self.assertIsNone(self.report()["observations"][0]["variable_acquisition_gbp"])

    def test_invalid_counts(self):
        row = self.observation()
        for value in (-1, 0.5, True, "100", float("nan")):
            with self.subTest(value=value):
                row["counts"]["video_impressions"] = value
                with self.assertRaises(registry.RegistryError):
                    self.report()

    def test_new_customers_cannot_exceed_orders(self):
        row = self.observation()
        row["counts"]["new_customers"] = 3
        with self.assertRaises(registry.RegistryError):
            self.report()

    def test_money_is_decimal_and_duplicate_cost_is_once(self):
        row = self.observation()
        self.cost(row, "0.10")
        self.data["costs"].append(copy.deepcopy(self.data["costs"][0]))
        self.assertEqual(self.report()["observations"][0]["variable_acquisition_gbp"], "0.10")
        for value in (0.1, "0.1", "-1.00", "NaN", "1e2"):
            with self.subTest(value=value), self.assertRaises(registry.RegistryError):
                registry.money(value)

    def test_cost_conflicts_and_ledger_ref_double_count(self):
        row = self.observation("actual")
        self.cost(row)
        other = copy.deepcopy(self.data["costs"][0])
        other["cost_id"] = "other-cost-id"
        self.data["costs"].append(other)
        with self.assertRaisesRegex(registry.RegistryError, "allocated twice"):
            self.report()

    def test_actual_costs_are_read_only_ledger_references(self):
        row = self.observation("actual")
        cost = self.cost(row)
        self.assertIsNone(self.report()["observations"][0]["variable_acquisition_gbp"])
        cost["amount_gbp"] = "12.00"
        with self.assertRaisesRegex(registry.RegistryError, "do not copy"):
            self.report()

    def test_ledger_lookup_validates_actual_category_and_date(self):
        row = self.observation("actual")
        self.cost(row)
        ledger = registry.load(ROOT.parent / "measurement/actual-ledger.empty.json")
        ledger["costs"].append({"store": "shared", "cost_id": "traffic-001", "category": "traffic", "incurred_at_utc": "2026-10-01T10:00:00Z", "amount_gbp": "12.00", "cash_paid_gbp": "12.00", "source": {"kind": "receipt", "reference": "test-receipt", "recorded_at_utc": "2026-10-02T10:00:00Z"}})
        path = self.path / "ledger.json"
        registry.save(path, ledger)
        before = path.read_bytes()
        result = registry.make_report(self.data, "2026-10-02", path)
        self.assertEqual(result["observations"][0]["rates"]["cac_per_new_customer_gbp"]["value"], "12.00")
        self.assertEqual(path.read_bytes(), before)
        ledger["scope"] = "simulation"
        registry.save(path, ledger)
        with self.assertRaises(registry.RegistryError):
            registry.make_report(self.data, "2026-10-02", path)

    def test_rights_unknown_blocks_both_channels_and_owned_needs_evidence(self):
        creative = self.data["creatives"][0]
        ready = registry.rights_readiness(creative, "2026-10-02")
        self.assertFalse(ready["organic"]["rights_ready"])
        self.assertFalse(ready["paid"]["rights_ready"])
        creative["footage_rights"]["status"] = "owned"
        with self.assertRaisesRegex(registry.RegistryError, "rights record"):
            self.report()

    def test_licensed_organic_does_not_cover_paid_and_expiry_blocks(self):
        creative = self.data["creatives"][0]
        self.data["sources"].append({"source_id": "license", "title": "Test licence reference", "url": None, "evidence_type": "rights_record", "recorded_on": "2026-10-01", "country": "GB", "reference": "opaque-licence-reference"})
        creative["footage_rights"] = {"status": "licensed", "evidence_source_id": "license", "allowed_uses": ["organic"], "expires_on": "2026-10-02"}
        rights = self.report()["creatives"][0]["rights"]
        self.assertTrue(rights["organic"]["rights_ready"])
        self.assertFalse(rights["paid"]["rights_ready"])
        self.assertFalse(registry.rights_readiness(creative, "2026-10-03")["organic"]["rights_ready"])

    def test_undeclared_factor_change_rejected(self):
        self.data["creatives"][1]["factors"]["offer"] = "An extra offer"
        with self.assertRaisesRegex(registry.RegistryError, "factor"):
            self.report()

    def test_csv_formula_injection_and_html_escaping(self):
        for cell in ("=SUM(1,2)", " +evil", "-1+2", "@evil", "\tevil", "\revil", "\nevil"):
            self.assertTrue(registry.safe_cell(cell).startswith("'"))
        self.data["creatives"][0]["label"] = "=SUM(1,2)"
        registry.export_creative_plan(self.data, self.path, "2026-10-02")
        with (self.path / "creative-plan.csv").open(newline="", encoding="utf-8") as handle:
            self.assertTrue(next(csv.DictReader(handle))["label"].startswith("'="))
        report = self.report()
        report["limitations"].append("<script>alert(1)</script>")
        registry.export_report(report, self.path)
        body = (self.path / "report.html").read_text()
        self.assertNotIn("<script>", body)
        self.assertIn("&lt;script&gt;", body)

    def test_reject_personal_fields_and_contact_urls(self):
        row = self.observation()
        row["customer_email"] = "fake@example.com"
        with self.assertRaises(registry.RegistryError):
            self.report()
        del row["customer_email"]
        self.data["sources"][0]["url"] = "https://example.com/?email=fake"
        with self.assertRaises(registry.RegistryError):
            self.report()

    def test_csv_blank_is_unknown_and_bad_count_stops_import(self):
        row = self.observation()
        self.data["observations"] = []
        headers = ["observation_id", "experiment_id", "creative_id", "scope", "stage", "country", "start_on", "end_on", "source_id", *registry.COUNTS, "notes"]
        values = [row[k] for k in headers[:9]] + ["" for _ in registry.COUNTS] + [row["notes"]]
        path = self.path / "input.csv"
        registry.write_csv(path, headers, [values])
        clean, added = registry.import_observations(self.data, path)
        self.assertEqual(added, 1)
        self.assertIsNone(clean["observations"][0]["counts"]["orders"])
        values[9] = "1.5"
        registry.write_csv(path, headers, [values])
        with self.assertRaises(registry.RegistryError):
            registry.import_observations(self.data, path)

    def test_plan_export_has_no_metrics_or_authorization(self):
        registry.export_creative_plan(self.data, self.path, "2026-10-02")
        plan = registry.load(self.path / "creative-plan.json")
        self.assertTrue(all("counts" not in c and "rates" not in c and not c["publish_authorized"] for c in plan["creatives"]))


if __name__ == "__main__":
    unittest.main()
