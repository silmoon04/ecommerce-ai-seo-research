"""Offline research registry. Python 3.10+, standard library only."""
from __future__ import annotations

import argparse
import copy
import csv
import html
import importlib.util
import json
import re
import sys
from datetime import date
from decimal import Decimal, InvalidOperation
from pathlib import Path
from urllib.parse import urlsplit

SCOPES = {"actual", "simulation", "claimed"}
STAGES = {"planned", "sample", "organic", "checkout", "paid", "retired"}
COUNTS = ("video_impressions", "content_plays", "destination_clicks", "landing_sessions", "checkout_starts", "orders", "new_customers")
FACTORS = ("hook", "demonstration", "audience", "offer", "format", "cta")
SOURCE_TYPES = {"measurement_export", "source_case", "supplier_quote", "rights_record", "planning_note", "simulation_fixture"}
ID = re.compile(r"^[a-z0-9][a-z0-9_-]{0,79}$")
ZERO = Decimal("0.00")


class RegistryError(ValueError):
    pass


def fields(row, required, optional=()):
    if not isinstance(row, dict):
        raise RegistryError("Expected an object")
    missing = set(required) - row.keys()
    extra = row.keys() - set(required) - set(optional)
    if missing or extra:
        raise RegistryError(f"Fields missing={sorted(missing)} unexpected={sorted(extra)}")


def identifier(value):
    if not isinstance(value, str) or not ID.fullmatch(value):
        raise RegistryError("IDs must be stable lowercase slugs, not personal identifiers")
    return value


def text_value(value):
    if not isinstance(value, str) or not value.strip() or len(value) > 1500:
        raise RegistryError("Text must contain 1 to 1500 characters")
    if re.search(r"\b[^\s@]+@[^\s@]+\.[^\s@]+\b", value) or re.search(r"(?:\+?\d[\s().-]*){10,}", value):
        raise RegistryError("Contact details do not belong in this registry")
    return value


def day(value):
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        raise RegistryError("Dates must use YYYY-MM-DD")
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise RegistryError("Invalid date") from exc


def country(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Z]{2}", value):
        raise RegistryError("Country must be a two-letter uppercase code")


def money(value):
    if not isinstance(value, str) or not re.fullmatch(r"\d+\.\d{2}", value):
        raise RegistryError("GBP amounts must be nonnegative decimal strings with two places")
    try:
        amount = Decimal(value)
    except InvalidOperation as exc:
        raise RegistryError("Invalid GBP amount") from exc
    if not amount.is_finite():
        raise RegistryError("GBP amount must be finite")
    return amount


def unique(rows, key):
    if not isinstance(rows, list):
        raise RegistryError("Record collections must be arrays")
    found = {}
    for row in rows:
        if not isinstance(row, dict) or key not in row:
            raise RegistryError(f"Missing {key}")
        identity = identifier(row[key])
        if identity in found and found[identity] != row:
            raise RegistryError(f"Conflicting duplicate {key}: {identity}")
        found[identity] = row
    return found


def validate(data):
    fields(data, ("schema_version", "currency", "products", "sources", "experiments", "creatives", "observations", "costs"))
    if type(data["schema_version"]) is not int or data["schema_version"] != 1 or data["currency"] != "GBP":
        raise RegistryError("Expected schema version 1 and GBP")
    products = unique(data["products"], "product_id")
    sources = unique(data["sources"], "source_id")
    experiments = unique(data["experiments"], "experiment_id")
    creatives = unique(data["creatives"], "creative_id")
    observations = unique(data["observations"], "observation_id")
    costs = unique(data["costs"], "cost_id")
    for row in products.values():
        fields(row, ("product_id", "name", "stage", "hypothesis"))
        text_value(row["name"])
        text_value(row["hypothesis"])
        if row["stage"] not in STAGES:
            raise RegistryError("Unknown product stage")
    for row in sources.values():
        fields(row, ("source_id", "title", "url", "evidence_type", "recorded_on", "country", "reference"))
        text_value(row["title"])
        identifier(row["reference"])
        day(row["recorded_on"])
        country(row["country"])
        if row["evidence_type"] not in SOURCE_TYPES:
            raise RegistryError("Unknown evidence type")
        if row["url"] is not None:
            if not isinstance(row["url"], str):
                raise RegistryError("Source URL must be text or null")
            try:
                url = urlsplit(row["url"])
                if url.scheme != "https" or not url.hostname or url.username or url.password or url.query or url.fragment:
                    raise RegistryError("Use a public HTTPS source URL without credentials, query or fragment")
            except ValueError as exc:
                raise RegistryError("Invalid source URL") from exc
        elif row["evidence_type"] in {"source_case", "supplier_quote"}:
            raise RegistryError("External case and supplier sources require a public source URL")
    for row in experiments.values():
        fields(row, ("experiment_id", "product_id", "stage", "country", "question", "baseline_creative_id", "changed_factors", "source_ids"))
        if row["product_id"] not in products or row["stage"] not in STAGES:
            raise RegistryError("Unknown experiment product or stage")
        country(row["country"])
        text_value(row["question"])
        if not isinstance(row["changed_factors"], list) or not row["changed_factors"] or len(set(row["changed_factors"])) != len(row["changed_factors"]) or not set(row["changed_factors"]) <= set(FACTORS):
            raise RegistryError("List the unique factors changed by the experiment")
        if not isinstance(row["source_ids"], list) or not row["source_ids"] or any(s not in sources for s in row["source_ids"]):
            raise RegistryError("Experiment needs known source IDs")
    for row in creatives.values():
        fields(row, ("creative_id", "experiment_id", "stage", "label", "factors", "footage_rights", "planned_action"))
        if row["experiment_id"] not in experiments or row["stage"] not in STAGES:
            raise RegistryError("Unknown creative experiment or stage")
        text_value(row["label"])
        text_value(row["planned_action"])
        fields(row["factors"], FACTORS)
        for value in row["factors"].values():
            text_value(value)
        rights = row["footage_rights"]
        fields(rights, ("status", "evidence_source_id", "allowed_uses", "expires_on"))
        if rights["status"] not in {"owned", "licensed", "unknown"}:
            raise RegistryError("Unknown footage rights status")
        if not isinstance(rights["allowed_uses"], list) or len(set(rights["allowed_uses"])) != len(rights["allowed_uses"]) or not set(rights["allowed_uses"]) <= {"organic", "paid"}:
            raise RegistryError("Rights uses must be organic and/or paid")
        if rights["status"] == "unknown":
            if rights["evidence_source_id"] is not None or rights["allowed_uses"]:
                raise RegistryError("Unknown rights cannot claim permission")
        elif rights["evidence_source_id"] not in sources or sources[rights["evidence_source_id"]]["evidence_type"] != "rights_record":
            raise RegistryError("Owned/licensed footage needs a rights record")
        if rights["expires_on"] is not None:
            day(rights["expires_on"])
    for row in experiments.values():
        baseline = creatives.get(row["baseline_creative_id"])
        if baseline is None or baseline["experiment_id"] != row["experiment_id"]:
            raise RegistryError("Experiment baseline must be one of its creatives")
        for variant in creatives.values():
            if variant["experiment_id"] == row["experiment_id"]:
                differences = {f for f in FACTORS if variant["factors"][f] != baseline["factors"][f]}
                if not differences <= set(row["changed_factors"]):
                    raise RegistryError("Creative changed a factor absent from the experiment declaration")
    windows = []
    for row in observations.values():
        fields(row, ("observation_id", "experiment_id", "creative_id", "scope", "stage", "country", "start_on", "end_on", "source_id", "counts", "notes"))
        creative = creatives.get(row["creative_id"])
        if creative is None or creative["experiment_id"] != row["experiment_id"]:
            raise RegistryError("Observation must reference a creative in its experiment")
        if row["scope"] not in SCOPES or row["stage"] not in {"sample", "organic", "checkout", "paid"}:
            raise RegistryError("Observation needs a measurement scope and completed measurement stage")
        country(row["country"])
        if row["country"] != experiments[row["experiment_id"]]["country"]:
            raise RegistryError("Observation country differs from its experiment")
        start, end = day(row["start_on"]), day(row["end_on"])
        if start > end:
            raise RegistryError("Observation window starts after it ends")
        source = sources.get(row["source_id"])
        expected = {"actual": "measurement_export", "simulation": "simulation_fixture", "claimed": "source_case"}[row["scope"]]
        if source is None or source["evidence_type"] != expected:
            raise RegistryError(f"{row['scope']} observations require {expected} provenance")
        if source["country"] != row["country"] or day(source["recorded_on"]) < end:
            raise RegistryError("Source country/date does not cover this observation")
        text_value(row["notes"])
        fields(row["counts"], COUNTS)
        for value in row["counts"].values():
            if value is not None and (type(value) is not int or value < 0):
                raise RegistryError("Counts must be nonnegative integers or null for unknown")
        orders, customers = row["counts"]["orders"], row["counts"]["new_customers"]
        if orders is not None and customers is not None and customers > orders:
            raise RegistryError("New customers cannot exceed orders")
        group = (row["creative_id"], row["scope"], row["stage"], row["country"])
        for old_group, old_start, old_end in windows:
            if group == old_group and start <= old_end and old_start <= end:
                raise RegistryError("Overlapping windows: import disjoint period totals, not repeated cumulative snapshots")
        windows.append((group, start, end))
    ledger_refs = set()
    for row in costs.values():
        fields(row, ("cost_id", "experiment_id", "creative_id", "observation_id", "scope", "category", "amount_gbp", "source_id", "ledger_ref"))
        creative = creatives.get(row["creative_id"])
        if creative is None or creative["experiment_id"] != row["experiment_id"]:
            raise RegistryError("Cost creative and experiment do not match")
        if row["scope"] not in SCOPES | {"planned"} or row["category"] not in {"sample", "setup", "variable_acquisition"}:
            raise RegistryError("Unknown cost scope/category")
        observation = observations.get(row["observation_id"])
        if row["scope"] == "planned":
            if row["observation_id"] is not None:
                raise RegistryError("Planned costs have no observation")
        elif observation is None or any(observation[k] != row[k] for k in ("experiment_id", "creative_id", "scope")):
            raise RegistryError("Measured cost needs an observation in the same scope")
        if row["scope"] == "actual":
            if row["amount_gbp"] is not None or row["source_id"] is not None:
                raise RegistryError("Actual costs use existing ledger references; do not copy amounts")
            fields(row["ledger_ref"], ("store", "cost_id"))
            key = tuple(identifier(row["ledger_ref"][k]) for k in ("store", "cost_id"))
            if key in ledger_refs:
                raise RegistryError("One ledger cost cannot be allocated twice")
            ledger_refs.add(key)
        else:
            money(row["amount_gbp"])
            source = sources.get(row["source_id"])
            allowed = {"planned": {"planning_note", "supplier_quote"}, "simulation": {"simulation_fixture"}, "claimed": {"source_case"}}[row["scope"]]
            if source is None or source["evidence_type"] not in allowed or row["ledger_ref"] is not None:
                raise RegistryError("Estimate cost needs matching source provenance and no actual ledger reference")
    clean = copy.deepcopy(data)
    for collection, values in (("products", products), ("sources", sources), ("experiments", experiments), ("creatives", creatives), ("observations", observations), ("costs", costs)):
        clean[collection] = list(values.values())
    return clean


def load(path):
    try:
        with Path(path).open(encoding="utf-8-sig") as handle:
            return json.load(handle)
    except (OSError, ValueError) as exc:
        raise RegistryError(f"Cannot read JSON: {exc}") from exc


def save(path, data):
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + ".tmp")
    temporary.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(target)


def import_observations(data, input_path):
    path = Path(input_path)
    if path.suffix.lower() == ".csv":
        expected = ["observation_id", "experiment_id", "creative_id", "scope", "stage", "country", "start_on", "end_on", "source_id", *COUNTS, "notes"]
        with path.open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if reader.fieldnames != expected:
                raise RegistryError("CSV headers must exactly match the observations template")
            incoming = []
            for row in reader:
                if None in row or any(v is None for v in row.values()):
                    raise RegistryError("Malformed CSV row")
                counts = {}
                for key in COUNTS:
                    value = row.pop(key).strip()
                    if value and not re.fullmatch(r"\d+", value):
                        raise RegistryError("CSV counts use integers; blank means unknown")
                    counts[key] = int(value) if value else None
                row["counts"] = counts
                incoming.append(row)
    else:
        incoming = load(path)
        if not isinstance(incoming, list):
            raise RegistryError("Observation import JSON must be an array")
    merged = copy.deepcopy(data)
    before = len(unique(data["observations"], "observation_id"))
    merged["observations"].extend(incoming)
    clean = validate(merged)
    return clean, len(clean["observations"]) - before


def rights_readiness(creative, as_of):
    rights = creative["footage_rights"]
    reasons = []
    if rights["status"] == "unknown":
        reasons.append("footage rights unknown")
    if rights["expires_on"] is not None and day(rights["expires_on"]) < day(as_of):
        reasons.append("rights expired")
    return {use: {"rights_ready": not reasons and use in rights["allowed_uses"], "reasons": reasons + ([] if use in rights["allowed_uses"] else [f"{use} use not covered"])} for use in ("organic", "paid")}


def ratio(numerator, denominator, precision="0.0001"):
    if numerator is None or denominator is None:
        return {"value": None, "reason": "missing numerator or denominator"}
    if denominator == 0:
        return {"value": None, "reason": "denominator is zero"}
    return {"value": str((Decimal(numerator) / Decimal(denominator)).quantize(Decimal(precision))), "reason": None}


def ledger_costs(path):
    if path is None:
        return None
    ledger_module = Path(__file__).resolve().parent.parent / "measurement" / "ledger.py"
    spec = importlib.util.spec_from_file_location("revival_existing_ledger", ledger_module)
    if spec is None or spec.loader is None:
        raise RegistryError("Existing financial ledger validator unavailable")
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
        raw = load(path)
        if raw.get("scope") != "actual":
            raise RegistryError("Actual cost references require an actual ledger")
        clean = module.validate(raw)
        return {(row["store"], row["cost_id"]): row for row in clean["costs"]}
    except (ValueError, OSError) as exc:
        raise RegistryError(f"Existing ledger failed validation: {exc}") from exc


def make_report(data, as_of, ledger_path=None):
    data = validate(data)
    day(as_of)
    actual_costs = ledger_costs(ledger_path)
    results = []
    for row in data["observations"]:
        if day(row["end_on"]) > day(as_of):
            raise RegistryError("Observation window ends after the report date")
        counts = row["counts"]
        scoped_costs = [c for c in data["costs"] if c["observation_id"] == row["observation_id"]]
        acquisition = [c for c in scoped_costs if c["category"] == "variable_acquisition"]
        total = ZERO
        cost_known = bool(acquisition)
        for cost in acquisition:
            if cost["scope"] == "actual":
                key = (cost["ledger_ref"]["store"], cost["ledger_ref"]["cost_id"])
                if actual_costs is None:
                    cost_known = False
                    continue
                if key not in actual_costs:
                    raise RegistryError("Referenced actual cost is absent from the supplied ledger")
                ledger_row = actual_costs[key]
                if ledger_row["category"] != "traffic":
                    raise RegistryError("Actual acquisition cost must reference the ledger traffic category")
                if not row["start_on"] <= ledger_row["incurred_at_utc"][:10] <= row["end_on"]:
                    raise RegistryError("Ledger acquisition cost is outside the observation window")
                total += money(ledger_row["amount_gbp"])
            else:
                total += money(cost["amount_gbp"])
        rates = {}
        for name, numerator, denominator in (
            ("destination_clicks_per_video_impression", "destination_clicks", "video_impressions"),
            ("destination_clicks_per_content_play", "destination_clicks", "content_plays"),
            ("orders_per_landing_session", "orders", "landing_sessions"),
            ("checkout_starts_per_landing_session", "checkout_starts", "landing_sessions"),
        ):
            rates[name] = {**ratio(counts[numerator], counts[denominator]), "numerator": numerator, "denominator": denominator}
        for name, denominator in (("cost_per_order_gbp", "orders"), ("cac_per_new_customer_gbp", "new_customers")):
            result = ratio(total if cost_known else None, counts[denominator], "0.01")
            rates[name] = {**result, "numerator": "variable_acquisition_gbp", "denominator": denominator}
        results.append({"observation_id": row["observation_id"], "creative_id": row["creative_id"], "experiment_id": row["experiment_id"], "scope": row["scope"], "stage": row["stage"], "country": row["country"], "start_on": row["start_on"], "end_on": row["end_on"], "counts": counts, "variable_acquisition_gbp": str(total) if cost_known else None, "rates": rates})
    return {
        "schema_version": 1, "as_of": as_of, "currency": "GBP",
        "actual_observation_records": sum(r["scope"] == "actual" for r in results),
        "scope_record_counts": {s: sum(r["scope"] == s for r in results) for s in sorted(SCOPES)},
        "observations": results,
        "sources": data["sources"],
        "creatives": [{"creative_id": c["creative_id"], "label": c["label"], "stage": c["stage"], "rights": rights_readiness(c, as_of), "publish_authorized": False} for c in data["creatives"]],
        "cost_estimates": [{"cost_id": c["cost_id"], "scope": c["scope"], "category": c["category"], "amount_gbp": c["amount_gbp"]} for c in data["costs"] if c["scope"] != "actual"],
        "limitations": ["Preparation only. Rights readiness is one check; it does not authorize publication or spend.", "Source-case figures remain claimed, never actual shop revenue.", "Organic comparisons are descriptive and cannot establish causation.", "Counts are disjoint window totals with separate units. Rates use the named denominators; views do not mean purchases.", "Missing denominators and zero orders/customers produce unknown cost ratios, never zero CAC.", "Financial truth, payment fees, refunds, supplier costs and profit remain in the existing measurement ledger. This report does not calculate revenue or profit."]
    }


def safe_cell(value):
    cell = "" if value is None else str(value)
    if cell.lstrip().startswith(("=", "+", "-", "@")) or cell.startswith(("\t", "\r", "\n")):
        return "'" + cell
    return cell


def write_csv(path, headers, rows):
    with Path(path).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(headers)
        for row in rows:
            writer.writerow([safe_cell(value) for value in row])


def export_report(report, output):
    target = Path(output)
    target.mkdir(parents=True, exist_ok=True)
    save(target / "report.json", report)
    rates = ["destination_clicks_per_video_impression", "destination_clicks_per_content_play", "orders_per_landing_session", "checkout_starts_per_landing_session", "cost_per_order_gbp", "cac_per_new_customer_gbp"]
    headers = ["observation_id", "creative_id", "scope", "stage", "country", "start_on", "end_on", *COUNTS, "variable_acquisition_gbp", *rates]
    rows = []
    for row in report["observations"]:
        rows.append([row[k] for k in headers[:7]] + [row["counts"][k] for k in COUNTS] + [row["variable_acquisition_gbp"]] + [row["rates"][k]["value"] for k in rates])
    write_csv(target / "observations.csv", headers, rows)
    escape = lambda value: html.escape(str(value))
    cards = []
    for row in report["observations"]:
        metrics = "".join(f"<tr><th>{escape(name)}</th><td>{escape(value['value'] if value['value'] is not None else 'unknown: ' + value['reason'])}</td></tr>" for name, value in row["rates"].items())
        cards.append(f"<article><h2>{escape(row['observation_id'])} ({escape(row['scope'])})</h2><p>{escape(row['creative_id'])}, {escape(row['stage'])}, {escape(row['country'])}, {escape(row['start_on'])} to {escape(row['end_on'])}</p><table>{metrics}</table></article>")
    rights = "".join(f"<tr><td>{escape(c['creative_id'])}<br>{escape(c['label'])}</td><td>{escape(c['stage'])}</td><td>{escape(json.dumps(c['rights']))}</td></tr>" for c in report["creatives"])
    source_rows = []
    for source in report["sources"]:
        title = escape(source["title"])
        if source["url"] is not None:
            title = f'<a href="{html.escape(source["url"], quote=True)}" rel="noreferrer">{title}</a>'
        source_rows.append(f"<tr><td>{escape(source['source_id'])}<br>{title}</td><td>{escape(source['evidence_type'])}</td><td>{escape(source['recorded_on'])}</td><td>{escape(source['country'])}</td></tr>")
    content = f"<!doctype html><html lang='en'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><meta http-equiv='Content-Security-Policy' content=\"default-src 'none'; style-src 'unsafe-inline'\"><title>Revival lab research report</title><style>body{{font:16px system-ui;margin:2rem auto;max-width:1100px;padding:0 1rem;color:#18332d;background:#faf9f5}}table{{border-collapse:collapse;width:100%;overflow-wrap:anywhere}}th,td{{padding:.65rem;text-align:left;border-bottom:1px solid #bbb}}article{{margin:2rem 0}}td:last-child{{max-width:650px}}</style><h1>Revival lab research report</h1><p>As of {escape(report['as_of'])}. Actual observation records: {report['actual_observation_records']}. Publication authorized: no.</p><ul>{''.join('<li>' + escape(note) + '</li>' for note in report['limitations'])}</ul>{''.join(cards) if cards else '<p>No observations have been imported. Planned variants have no performance metrics.</p>'}<h2>Creative rights</h2><table><tr><th>Creative</th><th>Stage</th><th>Checks</th></tr>{rights}</table><h2>Sources</h2><table><tr><th>Source</th><th>Evidence type</th><th>Recorded</th><th>Country</th></tr>{''.join(source_rows)}</table></html>"
    (target / "report.html").write_text(content, encoding="utf-8")


def export_creative_plan(data, output, as_of):
    data = validate(data)
    target = Path(output)
    target.mkdir(parents=True, exist_ok=True)
    rows = []
    experiments = {row["experiment_id"]: row for row in data["experiments"]}
    for row in data["creatives"]:
        experiment = experiments[row["experiment_id"]]
        rows.append({"creative_id": row["creative_id"], "experiment_id": row["experiment_id"], "product_id": experiment["product_id"], "baseline_creative_id": experiment["baseline_creative_id"], "changed_factors": experiment["changed_factors"], "source_ids": experiment["source_ids"], "stage": row["stage"], "label": row["label"], "factors": row["factors"], "planned_action": row["planned_action"], "footage_rights": row["footage_rights"], "rights_checks": rights_readiness(row, as_of), "publish_authorized": False})
    save(target / "creative-plan.json", {"as_of": as_of, "purpose": "research preparation", "sources": data["sources"], "creatives": rows})
    headers = ["creative_id", "experiment_id", "stage", "label", *FACTORS, "planned_action", "rights_status", "organic_rights_ready", "paid_rights_ready", "publish_authorized"]
    write_csv(target / "creative-plan.csv", headers, [[r[k] for k in headers[:4]] + [r["factors"][f] for f in FACTORS] + [r["planned_action"], r["footage_rights"]["status"], r["rights_checks"]["organic"]["rights_ready"], r["rights_checks"]["paid"]["rights_ready"], False] for r in rows])


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("validate", "import-observations", "report", "export-creative-plan"):
        command = sub.add_parser(name)
        command.add_argument("registry", type=Path)
        if name == "import-observations":
            command.add_argument("input", type=Path)
            command.add_argument("--output", required=True, type=Path, help="Destination registry; input registry is never overwritten implicitly")
        if name in {"report", "export-creative-plan"}:
            command.add_argument("--output", required=True, type=Path)
            command.add_argument("--as-of", default=date.today().isoformat())
        if name == "report":
            command.add_argument("--ledger", type=Path, help="Optional existing actual ledger, read only")
    args = parser.parse_args(argv)
    try:
        data = validate(load(args.registry))
        if args.command == "validate":
            print(f"Valid registry: {len(data['creatives'])} creatives; {len(data['observations'])} observations; actual={sum(r['scope'] == 'actual' for r in data['observations'])}")
        elif args.command == "import-observations":
            clean, added = import_observations(data, args.input)
            save(args.output, clean)
            print(f"Appended {added} observations; identical retries ignored. Saved {args.output}")
        elif args.command == "report":
            export_report(make_report(data, args.as_of, args.ledger), args.output)
            print(f"Saved offline report to {args.output / 'report.html'}")
        else:
            export_creative_plan(data, args.output, args.as_of)
            print(f"Saved creative plan to {args.output}")
        return 0
    except (RegistryError, OSError, TypeError, KeyError) as exc:
        print(f"Registry error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
