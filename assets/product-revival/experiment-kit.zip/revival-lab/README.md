# Revival lab

This is a small offline registry for the product revival research. It keeps a product, experiment and creative ID attached to each variant, records the factors being changed, and produces a report you can open as a local HTML file. Python 3.10 or later is enough. It uses the standard library and makes no network requests.

Use `registry.shortlist.json` as the current research seed. It contains the heatless curl comfort kit and adjustable blackout sleep mask, with three planned hook variants each. The curl openings cover morning result, overnight comfort and real wrapping technique; the mask openings cover daylight gap, side pressure and fit adjustment. Each comparison keeps the same footage, background, demonstration, audience, offer and CTA. Only the opening caption or narration changes, and product claims depend on future sample findings.

`registry.planned.json` remains the original schema example used by the tests: six planned openings across the Pilates grip sock rotation pack, renter soft-rubber hair kit and heatless curl comfort kit. Both seeds contain no observations, actual orders, costs or revenue records. All footage rights are unknown, so organic and paid rights checks fail. The quote shortlist does not select a funded product or authorize publication, purchases or advertising.

Run these commands from the repository root:

```powershell
python shopify-launch/revival-lab/registry.py validate shopify-launch/revival-lab/registry.shortlist.json
python shopify-launch/revival-lab/registry.py report shopify-launch/revival-lab/registry.shortlist.json --as-of 2026-10-02 --output shopify-launch/revival-lab/exports/shortlist
python shopify-launch/revival-lab/registry.py export-creative-plan shopify-launch/revival-lab/registry.shortlist.json --as-of 2026-10-02 --output shopify-launch/revival-lab/exports/shortlist
python -m unittest discover -s shopify-launch/revival-lab -p test_registry.py -v
```

Open `exports/shortlist/report.html` directly in a browser. The original example report remains in `exports/planned/`. These reports are static files with no tracking or remote assets. Each folder holds JSON and spreadsheet-safe CSV exports. Rates in the CSV are decimal ratios: `0.0200` means 2%, with the denominator named in the column. Blank values mean unknown, including zero-order cost ratios.

## Record an experiment

Copy `registry.shortlist.json` to a working registry for the current candidates. Use `registry.planned.json` only when following the older schema and simulation examples below. IDs are stable lowercase slugs; the shortlist has separate experiment IDs to keep those examples distinct. A changed hook needs a new creative ID; changing an old record would overwrite the meaning of its observations. Each experiment names a baseline creative and its changed factors. Validation rejects changes to undeclared factors. If several factors change, list all of them and treat the comparison accordingly.

Add sources before importing observations. A source has a public HTTPS URL where available, an evidence type, recording date, country and opaque reference. External case studies and supplier quotes require a URL. Internal measurement exports, ownership records and planning notes may use `null` for the URL. Keep source links free of login credentials, query parameters and fragments; choose the public canonical page. The reference points to your own evidence without copying its contents here.

Use these evidence types:

| Evidence type | Purpose |
| --- | --- |
| `planning_note` | Research question or intended offer |
| `supplier_quote` | Public supplier evidence for a planned estimate |
| `source_case` | A third party's case figures, always claimed |
| `measurement_export` | Your own aggregate observation, actual scope |
| `simulation_fixture` | Invented observations, simulation scope |
| `rights_record` | An opaque reference to ownership or a licence |

The `recorded_on` date must cover the observation's ending date and the source country must match. `GB` is used for the UK examples. Country fields accept two uppercase letters; you are responsible for choosing the correct country and checking the source's coverage. A worldwide case with no UK breakdown cannot become a UK actual record.

## Import observations

`templates/observations.csv` is a blank capture layout. JSON imports are arrays of observation objects, as shown in `examples/observation.simulation.json`. That example is invented and requires the separate simulation source object from `examples/source.simulation.json` to be added to a working registry first. Keep that demonstration in a separate simulation registry.

```powershell
python shopify-launch/revival-lab/registry.py import-observations shopify-launch/revival-lab/registry.working.json shopify-launch/revival-lab/templates/observations.csv --output shopify-launch/revival-lab/registry.next.json
python shopify-launch/revival-lab/registry.py report shopify-launch/revival-lab/registry.next.json --output shopify-launch/revival-lab/exports/working
```

Import is append-only: an identical observation ID and payload is ignored; a conflicting retry fails before the destination is written. Windows for the same creative, scope, stage and country must be disjoint. Import period totals, rather than overlapping lifetime or cumulative snapshots. The utility keeps each observation separate and never sums video plays, impressions and website sessions into a single audience figure.

Counts must be nonnegative integers. Use JSON `null` or a blank CSV cell when a count is unknown. A measured zero is different. Keep `video_impressions`, `content_plays`, `destination_clicks`, `landing_sessions`, `checkout_starts`, `orders` and `new_customers` separate. Orders per landing session uses landings; clicks per video impression uses video impressions. Cost per order uses orders. CAC uses new customers, which may be unknown even when orders are known. Zero orders or zero new customers produces an unknown cost ratio, never a CAC of zero.

Actual observations require your own measurement-export provenance. Simulation requires a simulation fixture. Third-party figures require source-case provenance and claimed scope. The registry has no revenue field. A source's claims, a video count and an organic comparison cannot establish your shop's revenue or causal sales lift. Validation checks structure and provenance labels; checking that a source is authentic remains a human evidence task.

## Costs and rights

Cost IDs are unique. The categories are `sample`, `setup` and `variable_acquisition`; only the last enters the cost-per-order and CAC research ratios. Identical cost retries count once and conflicting duplicates fail. A sample or setup estimate should appear once, rather than being copied into every variant. No cost is inferred from the absence of a record.

`examples/costs.json` shows the two shapes. Its £30 sample figure is an illustrative placeholder, not a supplier quote or current expense. The actual reference is a shape example that will fail until its referenced observation and ledger transaction exist. Planned, simulation and claimed amounts use GBP strings such as `"30.00"` and matching source provenance. Actual records contain no amount or copied receipt; they point to a `(store, cost_id)` in the existing financial ledger. The same ledger cost cannot be assigned twice. This version allocates one whole cost record to one observation, with no inferred shared allocation.

To resolve actual acquisition references, pass `--ledger` to `report`. It reads and validates the existing ledger without writing it. Only the existing ledger's `traffic` category can supply an acquisition amount, and its UTC date must fall inside the observation window. Without a supplied ledger, cost ratios remain unknown. The existing ledger currently accepts its ten store namespaces plus `shared`; a future revival merchant namespace needs a separately reviewed financial-ledger change. Do not rename a transaction to get it through this registry. Payment fees, supplier costs, refunds, settlements and profit remain the responsibility of that ledger; this report does not calculate them.

Footage rights are `owned`, `licensed` or `unknown`. Owned and licensed states need a `rights_record` source, allowed uses (`organic` and/or `paid`) and an optional expiry date. Organic permission does not cover paid advertising automatically. Unknown or expired rights block the corresponding readiness check. A rights check describes the evidence recorded here; it does not grant permission or meet every launch gate. Store licence files and participant permissions privately, referenced by an opaque ID. Do not import contact details, customer IDs, photographs, customer content or media files. Field whitelists reject additional payload fields, and the text checker rejects obvious email addresses and phone-like strings; it is not a complete personal-data detector.

## File contract

The JSON field names in the planned registry and examples are the version 1 contract. Counts are integers or `null`; GBP amounts are strings with two decimal places; dates use `YYYY-MM-DD`; flags in exports are booleans. Validation rejects missing and unexpected fields. Keep evidence in the source registry rather than inventing a URL for an internal record. CLI status 0 means the requested local operation succeeded; status 1 means invalid input or a file error. A successful report is preparation evidence, not a launch verdict.
